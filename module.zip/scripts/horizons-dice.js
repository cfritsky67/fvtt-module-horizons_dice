Hooks.on('diceSoNiceReady', (dice3d) => {

	dice3d.addTexture("Clueless", {
	    name: "Clueless",
	    composite: "multiply",
	    source: "modules/horizons-dice/textures/stills/clueless.webp",
	    bump: "modules/horizons-dice/textures/stills/clueless.webp"
	});



});
