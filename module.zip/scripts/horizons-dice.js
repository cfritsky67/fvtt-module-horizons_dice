Hooks.on('diceSoNiceReady', (dice3d) => {

	dice3d.addTexture("Clueless", {
	    name: "HDC - Clueless",
	    composite: "multiply",
	    source: "modules/horizons-dice/textures/animated/clueless.webm",
	    bump: "modules/horizons-dice/textures/animated/clueless.webm"
	});



});
