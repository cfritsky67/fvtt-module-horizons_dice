Hooks.on('diceSoNiceReady', (dice3d) => {

	dice3d.addTexture("giftest", {
	    name: "HDC - giftest",
	    composite: "multiply",
	    source: "modules/horizons-dice/textures/animated/giftest.gif",
	});



});
