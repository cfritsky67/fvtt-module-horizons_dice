Hooks.once('diceSoNiceInit', (dice3d) => {
    
    dice3d.addTexture("Clueless", {
        name: "☄️Clueless",
        composite: "source-over",
        source: "modules/horizon_dice/horizons-dice/textures/animated/clueless.webm",
        bump:"modules/horizon_dice/horizons-dice/textures/animated/clueless.webm"
    });

});
